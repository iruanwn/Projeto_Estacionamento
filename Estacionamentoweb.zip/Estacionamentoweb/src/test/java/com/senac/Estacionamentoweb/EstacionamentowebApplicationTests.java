package com.senac.Estacionamentoweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstacionamentowebApplicationTests {

	@Test
	void contextLoads() {
	}

}
