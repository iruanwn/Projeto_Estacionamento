package com.senac.Estacionamentoweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstacionamentowebApplication {

	public static void main(String[] args) {
		SpringApplication.run(EstacionamentowebApplication.class, args);
	}

}
